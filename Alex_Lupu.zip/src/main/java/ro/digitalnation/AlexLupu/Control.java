package ro.digitalnation.AlexLupu;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestParam;
@Controller
public class Control {
	@GetMapping("/greet")
	public String greet(@RequestParam(name="coef") String coef,Model model) {
	int a,b,c;
	String[] c2 = coef.split(",", 3);
	a=Integer.valueOf(c2[0]);
	b=Integer.valueOf(c2[1]);
	c=Integer.valueOf(c2[2]);
	double d=b*b-4*a*c;
	if(d>0)
	{
		model.addAttribute("name", "2 solutii reale : ");
		if(Math.sqrt(d)==(int)Math.sqrt(d))
		{
			double e=(-Math.sqrt(d)-b)/(2*a);
			if(e==(int)e)
			    model.addAttribute("x1", (int)e);
			else
			    model.addAttribute("x1", e);	
			e=(Math.sqrt(d)-b)/(2*a);
			if(e==(int)e)
				model.addAttribute("x2", (int)e);
			else
				model.addAttribute("x2", e);
		}
		else
		{
			if(d==(int)d)
			{
				model.addAttribute("x1", "("+(-b)+Math.sqrt((int)d)+")/"+2*a);
				model.addAttribute("x2", "("+(-b)+"-"+Math.sqrt((int)d)+")/"+2*a);
			}
			else
			{
				model.addAttribute("x1", "("+(-b)+Math.sqrt(d)+")/"+2*a);
				model.addAttribute("x2", "("+(-b)+"-"+Math.sqrt(d)+")/"+2*a);
			}
				
		}
	}
	if(d==0)
	{
		model.addAttribute("name", "1 solutie reala: ");
		double e=(-b)/(2*a);
		if(e==(int)e)
		model.addAttribute("x1", (int)e);
		else
		model.addAttribute("x1", e);
		model.addAttribute("x2", "");
	}
	if(d<0)
	{
		model.addAttribute("name", "0 solutii reale :");
		d=-1*d;
		boolean ok;
		if(Math.sqrt(d)==(int)Math.sqrt(d))
			ok=true;
		else
			ok=false;
		if(ok==true)
		{
			if(d==(int)d)
			{
				model.addAttribute("x1", "("+(-b)+"+i"+Math.sqrt((int)d)+")/"+2*a);
		        model.addAttribute("x2", "("+(-b)+"-i"+Math.sqrt((int)d)+")/"+2*a);
			}
			else
			{
				model.addAttribute("x1", "("+(-b)+"+i"+Math.sqrt(d)+")/"+2*a);
		        model.addAttribute("x2", "("+(-b)+"-i"+Math.sqrt(d)+")/"+2*a);
			}
		
		}
		else
		{
			if(d==(int)d)
			{
				model.addAttribute("x1", "("+(-b)+"+i*sqrt("+(int)d+"))/"+2*a);
				model.addAttribute("x2", "("+(-b)+"-i*sqrt("+(int)d+"))/"+2*a);
			}
			else
			{
			    model.addAttribute("x1", "("+(-b)+"+i*sqrt("+d+"))/"+2*a);
			    model.addAttribute("x2", "("+(-b)+"-i*sqrt("+d+"))/"+2*a);
			}
		}
	}
	return "greet";
}
}
